# Calculator App current state
Generated from installed code and live database: 2026-09-30T01:28:33.443071+00:00
Project: C:\Docker-Projects\Freight-Calc-v1.6
Last installed package: Calc_Continuity_Manual_Only_0930.1043
Latest Product Master upload: {"filename":"products.xls","id":2,"sha256":"86b404a6232f45c361b07f3b2db892c8d3516880eff69bc1687b91f9fa26f515","status":"VALIDATED","uploaded_at":"2026-09-25T02:04:54.432133+00:00"}
Active validated Product Master: {"filename":"products.xls","id":2,"sha256":"86b404a6232f45c361b07f3b2db892c8d3516880eff69bc1687b91f9fa26f515","uploaded_at":"2026-09-25T02:04:54.432133+00:00","validation_status_counts":{"EMPTY_CUSTOMER":3,"LINKED":413,"UNKNOWN_CUSTOMER":801,"UNLINKED":37445}}

## Preserved project decisions
# Calculator App rules preserved for continuation

- `Customer` is the imported Translogic customer. A linked `Client` is its Calculator Customer. The special `* / All Customers` cannot own Product Master or become a Calculator Customer.
- `products.xls` is a global Product Master. Its `CUSTOMER` column resolves the `Customer` by code and then its linked Calculator Customer; Product identity is `Client + SKU`. Do not add `Product.customer_code`.
- `ExternalDataFile` remains scoped to one Calculator Customer. Product Master uploads and comparison are separate from that upload flow.
- Customer access and authorisation are enforced in the backend. Global Product Master data must be exposed only within the authorised Calculator Customer scope.
- Product Master comparison, Product Reconciliation, Correction Rounds, decisions and Reconciliation Memory are the existing workflow. Review and Preview must not modify operational Products. Explicit Apply is required; preserve audit/history and guarded business rollback.
- Source-only import creates only missing Products for the selected Calculator Customer, using existing validation, unit conversion and freight type rules. Ineligible rows stay pending.
- Incremental updates use `01_Open_PowerShell_Here.bat`, `02_Apply_Update.bat`, `03_Rollback_Update.bat` and `04_Verify_Update.bat`, with baseline checks, backups, hashes, logs and rollback. Do not modify Git remote automatically.
- `04_Verify_Update.bat` performs verification only and must never create or publish a Continuity Snapshot. `05_Create_Continuity_Snapshot.bat` is the manual snapshot launcher and delegates to the installed tool. Apply, rollback and verification must not run snapshot creation automatically.

These are curated project decisions. The generated state and code archive, taken from the actual installation, determine what is currently implemented.

## Known points to revalidate

- In the development export on 29 September 2026, the full suite had four login-message expectation failures and two saved-estimate email-template failures. These are **not** a claim about the installed project's current test result; rerun the full suite to confirm or close them.

## Technical state
Database vendor: postgresql
Products: 372; Calculator Customers: 3; Customers: 111
Quotations: 15; Reconciliation decisions: 375; Correction Rounds: 8; Memory: 396
Decision statuses: {"APPLIED":375}
Correction Round statuses: {"APPLIED":5,"DISCARDED":2,"DRAFT":1}

## Migrations applied
- admin.0001_initial
- admin.0002_logentry_remove_auto_add
- admin.0003_logentry_add_action_flag_choices
- audit.0001_initial
- audit.0002_fuel_audit_fields
- auth.0001_initial
- auth.0002_alter_permission_name_max_length
- auth.0003_alter_user_email_max_length
- auth.0004_alter_user_username_opts
- auth.0005_alter_user_last_login_null
- auth.0006_require_contenttypes_0002
- auth.0007_alter_validators_add_error_messages
- auth.0008_alter_user_username_max_length
- auth.0009_alter_user_last_name_max_length
- auth.0010_alter_group_name_max_length
- auth.0011_update_proxy_permissions
- auth.0012_alter_user_first_name_max_length
- authentication_gateway.0001_calculator_user_profile
- carriers.0001_initial
- carriers.0002_excel_flags
- carriers.0003_fuel_provenance
- clients.0001_initial
- clients.0002_alter_client_options_customer_customerimport
- contenttypes.0001_initial
- contenttypes.0002_remove_content_type_name
- imports.0001_initial
- imports.0002_fuel_admin_import
- imports.0003_product_stock_reference_sources
- imports.0004_external_data_file_permissions
- imports.0005_externaldatafile_ftp_drop_source
- imports.0006_external_data_review_item
- imports.0007_external_data_review_correction_fields
- imports.0008_external_data_review_historical_selection
- imports.0009_product_source_rejected_rows
- imports.0010_product_source_repair_review
- imports.0011_external_data_correction_memory
- imports.0012_product_reconciliation_workspace
- imports.0013_product_reconciliation_apply
- imports.0014_product_correction_rounds
- imports.0015_productsourcerejectedrow_customer_code_and_more
- imports.0016_productmaster
- locations.0001_initial
- products.0001_initial
- products.0002_remove_product_products_pr_client__abaa70_idx_and_more
- products.0003_restore_client_sku_identity
- rates.0001_initial
- rates.0002_increase_freightrate_precision
- saved_estimates.0001_initial
- saved_estimates.0002_savedestimate_reference_max_length
- sessions.0001_initial

## Product Master and Reconciliation by Calculator Customer
Calculator Customer | Master rows | Operational | Active | Inactive | Same | Different | Source only | Operational only | Eligible | Blocked | Duplicates | Invalid | Comparison
STH | 413 | 372 | 372 | 0 | 266 | 103 | 44 | 3 | 0 | 44 | 0 | 0 | available
TEMP | Unavailable | 0 | 0 | 0 | Unavailable | Unavailable | Unavailable | Unavailable | Unavailable | Unavailable | Unavailable | Unavailable | no_linked_customer
temp2 | Unavailable | 0 | 0 | 0 | Unavailable | Unavailable | Unavailable | Unavailable | Unavailable | Unavailable | Unavailable | Unavailable | no_linked_customer

## Source files and code
See SOURCE_FILES.txt for active source names and hashes, CODE_FILE_HASHES.csv for installed source hashes, and BASELINE_CODE.zip for the allowlisted code snapshot.

## Known pending points
No machine-readable issue register is part of the Calculator App. Review the latest full test result and operational differences before inferring any further pending work. A comparison marked Unavailable cannot be treated as zero.
